import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class square extends Thread {
    public grid g;
    public JButton j;
    public String state;
    public int x, y, surPos, waitTime;

    public square(int x1, int y1, int wT){
        waitTime = wT;
        state = "O";
        j = new JButton(state);
        j.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                state = "X";
                j.setText(state);
            }
        });
        j.setPreferredSize(new Dimension(3, 3));
        x = x1;
        y = y1;
    }

    public void setGrid(grid g1){
        g = g1;
    }

    public void run(){
        while(true) {
            System.out.println("Square " + Integer.toString(x) + " " + Integer.toString(y));
            //checks each direction
            surPos = 0;
            if (x != 19) {
                if (g.squares[x + 1][y].state == "X") {
                    surPos += 1;
                }
            }
            if (x != 0) {
                if (g.squares[x - 1][y].state == "X") {
                    surPos += 1;
                }
            }
            if (y != 19) {
                if (g.squares[x][y + 1].state == "X") {
                    surPos += 1;
                }
            }
            if (y != 0) {
                if (g.squares[x][y - 1].state == "X") {
                    surPos += 1;
                }
            }
            //changes to X or O
            if (state == "O" && surPos == 3) {
                state = "X";
            } else if (state == "X" && surPos < 2) {
                state = "O";
            } else if (state == "X" && surPos > 3) {
                state = "O";
            }
            j.setText(state);
            try{ currentThread().sleep(waitTime*1000); } catch(Exception e){}
        }

    }
}
