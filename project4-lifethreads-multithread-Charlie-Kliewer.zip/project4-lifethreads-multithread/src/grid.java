import java.awt.*;
import javax.swing.*;
public class grid {
    JFrame frame;
    JPanel mainPanel;
    public square[][] squares;
    boolean ready;

    public grid(int t){
        frame = new JFrame("The GAME OF LIFE - TO BEGIN - PRESS TOP LEFT CELL");
        mainPanel = new JPanel(new GridLayout(20, 20));
        mainPanel.setSize(new Dimension(500,500));
        frame.setSize(new Dimension(500, 500));
        squares = new square[20][20];
        for(int b = 0; b < 20; b++){
            for(int z = 0; z < 20; z++){
                square s = new square(b, z, t);
                squares[b][z] = s;
                mainPanel.add(s.j);
            }
        }
        for(int b = 0; b < 20; b++){
            for(int z = 0; z < 20; z++){
                squares[b][z].setGrid(this);
            }
        }


        frame.add(mainPanel);
        frame.setVisible(true);

    }

    public void runGame(){

        while(!ready){
            if(squares[0][0].j.getText() == "X") {
                ready = true;
            }
            System.out.println("waiting for ready (press top left cell)");
        }
        System.out.println("READY!");
        //while(true) {
            for (int b = 0; b < 20; b++) {
                for (int z = 0; z < 20; z++) {
                    squares[b][z].start();
                }
            }
        //}

    }
}
