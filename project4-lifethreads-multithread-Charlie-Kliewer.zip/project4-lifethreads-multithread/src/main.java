
public class main {
    public static void main(String[] args){
        //Input wait time (seconds) in between cell run events, 0 for immediately
        int TIME_BETWEEN_EVENTS = 1;
        grid g = new grid(TIME_BETWEEN_EVENTS);
        g.runGame();
    }
}


